SKIPUNZIP=0
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/bin/sprd_brightness_fix 0 0 0755
set_perm $MODPATH/service.sh 0 0 0755
set_perm $MODPATH/uninstall.sh 0 0 0755
if [ -d /data/adb/modules/sprd_brightness_fix ]; then
  ui_print "! Full sprd_brightness_fix module is installed: remove it, the two conflict"
fi
if [ ! -e /sys/class/backlight/sprd_backlight/brightness ]; then
  ui_print "! sprd_backlight not found: this device may not need the fix"
fi
