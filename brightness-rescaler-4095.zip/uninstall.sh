#!/system/bin/sh
pkill -f sprd_brightness_fix 2>/dev/null
