#!/system/bin/sh
MODDIR=${0%/*}

until [ "$(getprop sys.boot_completed)" = "1" ]; do
  sleep 2
done
sleep 5

[ -e /sys/class/backlight/sprd_backlight/brightness ] || exit 0

chmod 755 "$MODDIR/bin/sprd_brightness_fix"
pkill -f "$MODDIR/bin/sprd_brightness_fix" 2>/dev/null
nohup "$MODDIR/bin/sprd_brightness_fix" >/dev/null 2>&1 &
